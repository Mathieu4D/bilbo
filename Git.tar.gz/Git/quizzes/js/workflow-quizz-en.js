var quizz = {
    title: 'Git - Branches and workflow',
    description: 'The goal of this quizz is to assess your knowledge of branching and various Git workflows',
    questions: [
        {
            type: 'free',
            text: 'How to list the branches?',
            answers: ['git branch -v', 'branch -v', 'git branch', 'branch']
        },
        {
            type: 'free',
            text: 'How to create a branch named `v1`?',
            answers: ['git branch v1', 'branch v1']
        },
        {
            type: 'free',
            text: 'How to switch onto a branch?',
            answers: ['git checkout', 'checkout']
        },
        {
            type: 'radio',
            text: 'When I commit, the current branch pointer moves to the newly created commit',
            answers: [
                {
                    text: 'True',
                    correct: true
                },
                {
                    text: 'False',
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'When I switch from `master` branch to `v1`, the pointer of the `master` branch moves to the commit pointed by `v1`',
            answers: [
                {
                    text: 'True',
                    correct: false
                },
                {
                    text: 'False',
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: 'How to create a branch and switch on it, with a single command?',
            answers: ['git checkout -b', 'checkout -b']
        },
        {
            type: 'free',
            text: 'How to delete a branch?',
            answers: ['git branch -d', 'branch -d']
        },
        {
            type: 'free',
            text: 'How to move a branch pointer?',
            answers: ['git reset', 'reset']
        },
        {
            type: 'free',
            text: "Which reset mode does not keep local changes nor the index?",
            answers: ['hard', '--hard']
        },
        {
            type: 'free',
            text: "Which command displays all the HEAD movements, and then enables to retrieve any committed change?",
            answers: ['git reflog', 'reflog']
        },
        {
            type: 'checkbox',
            text: "Which command(s) allow to integrate the work of two branches?",
            answers: [
                {
                    text: "reset",
                    correct: false
                },
                {
                    text: "merge",
                    correct: true
                },
                {
                    text: "rebase",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "I'm currently on commit `E`, and I want to obtain \n\n"
                + "    A <- B <- C <- D <- E \n\n"
                + " from the current history \n\n"
                + "    A <- B <- C \n\n"
                + "         | \n\n"
                + "         -  D <- E \n\n"
                + "Which command should I run?",
            answers: ['git rebase C', 'rebase C']
        },
        {
            type: 'free',
            text: "How to continue a rebase after a conflict resolution?",
            answers: ['git rebase --continue', 'rebase --continue']
        },
        {
            type: 'free',
            text: "How to cancel an unconcluded rebase?",
            answers: ['git rebase --abort', 'rebase --abort']
        },
        {
            type: 'free',
            text: "How to cancel an unconcluded merge?",
            answers: ['git merge --abort', 'merge --abort']
        },
        {
            type: 'free',
            text: "How to rebase in interactive mode?",
            answers: ['git rebase -i', 'rebase -i', '-i', 'git rebase --interactive', 'rebase --interactive', '--interactive']
        }
    ]
};
angular.module("workflow-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("workflow-quizz").constant('quizz', quizz);
