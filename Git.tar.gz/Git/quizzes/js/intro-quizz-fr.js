var quizz = {
    title: 'Git - Introduction',
    description: 'Ce quizz a pour but de tester vos connaissances sur les concepts de Git',
    questions: [
        {
            type: 'radio',
            text: 'En quelle année Git a-t-il été créé ?',
            answers: [
                {
                    text: "1998",
                    correct: false
                },
                {
                    text: "2002",
                    correct: false
                },
                {
                    text: "2005",
                    correct: true
                },
                {
                    text: "2008",
                    correct: false
                }
            ]
        },
        {
            type: 'checkbox',
            text: 'Quels sont les avantages de Git par rapport à SVN et consorts ?',
            answers: [
                {
                    text: "gestion simple des branches",
                    correct: true
                },
                {
                    text: "résolution automatique de tous les conflits",
                    correct: false
                },
                {
                    text: "pas de connexion réseau requise pour travailler en local",
                    correct: true
                },
                {
                    text: "vitesse",
                    correct: true
                }
            ]
        },
        {
            type: 'radio',
            text: 'Avec Git, dès qu\'une modification est commitée, il est possible de la retrouver.',
            answers: [
                {
                    text: "Vrai",
                    correct: true
                },
                {
                    text: "Faux",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'Il est possible de faire un commit en étant `offline`.',
            answers: [
                {
                    text: "Vrai",
                    correct: true
                },
                {
                    text: "Faux",
                    correct: false
                }
            ]
        },
        {
            type: 'checkbox',
            text: 'Quels sont les 3 niveaux de configuration de Git ?',
            answers: [
                {
                    text: "system",
                    correct: true
                },
                {
                    text: "group",
                    correct: false
                },
                {
                    text: "global",
                    correct: true
                },
                {
                    text: "local",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "Comment lister toutes les options de configuration de votre poste ?"
                + "    git config --??",
            answers: ['list']
        },
        {
            type: 'free',
            text: "Comment voir la valeur de mon nom d'utilisateur git ?\n"
                + "    git config ??",
            answers: ['--get user.name','user.name']
        },
        {
            type: 'free',
            text: "Combien y a-t-il de 'zones' Git?",
            answers: ['3']
        },
        {
            type: 'radio',
            text: 'Si un fichier modifié est un article de supermarché, comment définir l\' `index` ?',
            answers: [
                {
                    text: "le passage en caisse",
                    correct: false
                },
                {
                    text: "le panier",
                    correct: true
                },
                {
                    text: "le coffre de la voiture",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'En suivant la même analogie, comment définir un `commit` ?',
            answers: [
                {
                    text: "le passage en caisse",
                    correct: true
                },
                {
                    text: "le panier",
                    correct: false
                },
                {
                    text: "le coffre de la voiture",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'En suivant la même analogie, comment définir le `repository git` ?',
            answers: [
                {
                    text: "le passage en caisse",
                    correct: false
                },
                {
                    text: "le panier",
                    correct: false
                },
                {
                    text: "le coffre de la voiture",
                    correct: true
                }
            ]
        }
    ]
};
angular.module("intro-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("intro-quizz").constant('quizz', quizz);
