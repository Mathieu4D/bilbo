var quizz = {
    title: 'Git - Commandes de base',
    description: 'Ce quizz a pour but de tester vos connaissances sur les commandes de base de Git',
    questions: [
        {
            type: 'free',
            text: 'Comment initialiser un repository Git dans votre projet ?',
            answers: ['git init', 'init']
        },
        {
            type: 'free',
            text: 'Comment afficher l\'état de votre répertoire de travail ?',
            answers: ['git status', 'status']
        },
        {
            type: 'free',
            text: 'Comment ajouter un nouveau fichier au suivi Git ?',
            answers: ['git add', 'add']
        },
        {
            type: 'free',
            text: 'Quel fichier permet d\'indiquer à Git d\'ignorer les changements sur certains patterns de fichiers ?',
            answers: ['.gitignore']
        },
        {
            type: 'free',
            text: 'Comment faire un commit ?',
            answers: ['git commit', 'commit', 'git commit -m']
        },
        {
            type: 'radio',
            text: "Mon répertoire de travail consiste en 2 sous répertoires (`src` et `test`), contenant chacun 2 fichiers (`Person` et `Hobby`). Je modifie le fichier `Person` de `src`, je l'ajoute à l'index et je commite. Combien d'objets Git seront créés ?",
            answers: [
                {
                    text: "1 objet Commit",
                    correct: false
                },
                {
                    text: "1 objet Commit et 1 objet Blob",
                    correct: false
                },
                {
                    text: "1 objet Blob et 1 objet Tree",
                    correct: false
                },
                {
                    text: "1 objet Commit, 1 objet Blob et 1 objet Tree",
                    correct: false
                },
                {
                    text: "1 objet Commit, 1 objet Blob et 2 objets Tree",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "Quelle est la longueur d'un SHA-1, en nombre de caractères ?",
            answers: ['40']
        },
        {
            type: 'free',
            text: "Comment voir la différence entre le workspace et l'index ?",
            answers: ['git diff', 'diff']
        },
        {
            type: 'free',
            text: "Comment voir la différence entre le workspace et le repo ?",
            answers: ['git diff HEAD', 'diff HEAD']
        },
        {
            type: 'free',
            text: "Comment supprimer un fichier ?",
            answers: ['git rm', 'rm']
        },
        {
            type: 'free',
            text: "Comment déplacer un fichier ?",
            answers: ['git mv', 'mv']
        },
        {
            type: 'free',
            text: "Comment afficher l'historique d'un projet ?",
            answers: ['git log', 'log']
        },
        {
            type: 'free',
            text: "Comment afficher les commits dans une branche `maintenance` mais pas encore dans `master` ?",
            answers: ['git log master..maintenance', 'log master..maintenance']
        },
        {
            type: 'free',
            text: "Comment oter un fichier modifié de l'index ?",
            answers: ['git reset', 'reset']
        },
        {
            type: 'free',
            text: "Comment annuler les changements locaux ?",
            answers: ['git checkout', 'checkout']
        }
    ]
};
angular.module("basics-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("basics-quizz").constant('quizz', quizz);
