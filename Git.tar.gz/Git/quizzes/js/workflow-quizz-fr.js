var quizz = {
    title: 'Git - Branches et workflow',
    description: 'Ce quizz a pour but de tester vos connaissances sur les branches et types de workflow Git',
    questions: [
        {
            type: 'free',
            text: 'Comment lister les branches ?',
            answers: ['git branch -v', 'branch -v', 'git branch', 'branch']
        },
        {
            type: 'free',
            text: 'Comment créer une branch `v1` ?',
            answers: ['git branch v1', 'branch v1']
        },
        {
            type: 'free',
            text: 'Comment changer de branche ?',
            answers: ['git checkout', 'checkout']
        },
        {
            type: 'radio',
            text: 'Lorsque je commite sur une branche, l\'étiquette de la branche bouge pour se positionner sur mon dernier commit',
            answers: [
                {
                    text: 'Vrai',
                    correct: true
                },
                {
                    text: 'Faux',
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'Lorsque je change de branche pour aller de `master` sur `v1`, l\'étiquette de la branche `master` bouge pour se positionner sur le commit de la branche `v1`',
            answers: [
                {
                    text: 'Vrai',
                    correct: false
                },
                {
                    text: 'Faux',
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: 'Comment créer une branche et se placer dessus à la fois ?',
            answers: ['git checkout -b', 'checkout -b']
        },
        {
            type: 'free',
            text: 'Comment supprimer une branche ?',
            answers: ['git branch -d', 'branch -d']
        },
        {
            type: 'free',
            text: 'Comment déplacer l\'étiquette d\'une branche ?',
            answers: ['git reset', 'reset']
        },
        {
            type: 'free',
            text: "Quel mode de reset ne conserve ni les modifications locales, ni l'index ?",
            answers: ['hard', '--hard']
        },
        {
            type: 'free',
            text: "Quelle commande permet de voir tous les mouvements de HEAD, et ainsi récupérer tout travail commité ?",
            answers: ['git reflog', 'reflog']
        },
        {
            type: 'checkbox',
            text: "Quelles commandes permettent de fusionner deux branches?",
            answers: [
                {
                    text: "reset",
                    correct: false
                },
                {
                    text: "merge",
                    correct: true
                },
                {
                    text: "rebase",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "Je suis actuellement sur le commit `E`, je veux obtenir \n\n"
                + "    A <- B <- C <- D <- E \n\n"
                + " depuis la situation \n\n"
                + "    A <- B <- C \n\n"
                + "         | \n\n"
                + "         -  D <- E \n\n"
                + "Quelle commande dois-je effectuer ?",
            answers: ['git rebase C', 'rebase C']
        },
        {
            type: 'free',
            text: "Comment puis-je poursuivre un rebase après une résolution de conflit ?",
            answers: ['git rebase --continue', 'rebase --continue']
        },
        {
            type: 'free',
            text: "Comment puis-je abandonner un rebase ?",
            answers: ['git rebase --abort', 'rebase --abort']
        },
        {
            type: 'free',
            text: "Comment puis-je abandonner un merge ?",
            answers: ['git merge --abort', 'merge --abort']
        },
        {
            type: 'free',
            text: "Comment faire un rebase en mode interactif ?",
            answers: ['git rebase -i', 'rebase -i', '-i', 'git rebase --interactive', 'rebase --interactive', '--interactive']
        }
    ]
};
angular.module("workflow-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("workflow-quizz").constant('quizz', quizz);
