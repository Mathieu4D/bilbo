var quizz = {
    title: 'Git - Introduction',
    description: 'The goal of this quizz is to assess your knowledge of Git concepts.',
    questions: [
        {
            type: 'radio',
            text: 'In what year have Git been created?',
            answers: [
                {
                    text: "1998",
                    correct: false
                },
                {
                    text: "2002",
                    correct: false
                },
                {
                    text: "2005",
                    correct: true
                },
                {
                    text: "2008",
                    correct: false
                }
            ]
        },
        {
            type: 'checkbox',
            text: 'What are the benefits of Git, versus SVN and others?',
            answers: [
                {
                    text: "easy branch management",
                    correct: true
                },
                {
                    text: "automatic resolution of any conflict",
                    correct: false
                },
                {
                    text: "no network needed to work locally",
                    correct: true
                },
                {
                    text: "speed",
                    correct: true
                }
            ]
        },
        {
            type: 'radio',
            text: 'With Git, as soon as a change is committed, it cannot be lost.',
            answers: [
                {
                    text: "True",
                    correct: true
                },
                {
                    text: "False",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'I can commit while being offline.',
            answers: [
                {
                    text: "True",
                    correct: true
                },
                {
                    text: "False",
                    correct: false
                }
            ]
        },
        {
            type: 'checkbox',
            text: 'What are the three levels of Git configuration?',
            answers: [
                {
                    text: "system",
                    correct: true
                },
                {
                    text: "group",
                    correct: false
                },
                {
                    text: "global",
                    correct: true
                },
                {
                    text: "local",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "Hot to display all the configuration options set on your machine?"
                + "    git config --??",
            answers: ['list']
        },
        {
            type: 'free',
            text: "How to display my Git username?\n"
                + "    git config ??",
            answers: ['--get user.name','user.name']
        },
        {
            type: 'free',
            text: "How many 'areas' are there in Git?",
            answers: ['3']
        },
        {
            type: 'radio',
            text: 'If a changed file is a product in a supermarket, how to define the `index`?',
            answers: [
                {
                    text: "the checkout with the cashier",
                    correct: false
                },
                {
                    text: "the basket",
                    correct: true
                },
                {
                    text: "the car trunk",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'By following the same analogy, what is a `commit`?',
            answers: [
                {
                    text: "the checkout with the cashier",
                    correct: true
                },
                {
                    text: "the basket",
                    correct: false
                },
                {
                    text: "the car trunk",
                    correct: false
                }
            ]
        },
        {
            type: 'radio',
            text: 'By following the same analogy, what is the `git repository` ?',
            answers: [
                {
                    text: "the checkout with the cashier",
                    correct: false
                },
                {
                    text: "the basket",
                    correct: false
                },
                {
                    text: "the car trunk",
                    correct: true
                }
            ]
        }
    ]
};
angular.module("intro-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("intro-quizz").constant('quizz', quizz);
