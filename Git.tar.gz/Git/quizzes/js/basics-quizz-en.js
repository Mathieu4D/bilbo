var quizz = {
    title: 'Git - Basic commands',
    description: 'The goal of this quizz is to assess your knowledge of Git basic commands',
    questions: [
        {
            type: 'free',
            text: 'How to initialize a Git repository in your project?',
            answers: ['git init', 'init']
        },
        {
            type: 'free',
            text: 'How to display the state of your workspace?',
            answers: ['git status', 'status']
        },
        {
            type: 'free',
            text: 'How to add a new file to Git tracking?',
            answers: ['git add', 'add']
        },
        {
            type: 'free',
            text: 'What is the specific file telling Git to ignore changes on some files matching given patterns?',
            answers: ['.gitignore']
        },
        {
            type: 'free',
            text: 'How to commit?',
            answers: ['git commit', 'commit', 'git commit -m']
        },
        {
            type: 'radio',
            text: "My workspace contains 2 subfolders (`src` and `test`), each one containing containing 2 files (`Person` and `Hobby`). I edit `Person` from `src`, add it to index, and commit. How many Git objects will be created?",
            answers: [
                {
                    text: "1 Commit object",
                    correct: false
                },
                {
                    text: "1 Commit object and 1 Blob object",
                    correct: false
                },
                {
                    text: "1 Blob object and 1 Tree object",
                    correct: false
                },
                {
                    text: "1 Commit object, 1 Blob object, and 1 Tree object",
                    correct: false
                },
                {
                    text: "1 Commit object, 1 Blob object, and 2 Tree objects",
                    correct: true
                }
            ]
        },
        {
            type: 'free',
            text: "What is the length of a SHA-1, in number of characters?",
            answers: ['40']
        },
        {
            type: 'free',
            text: "How to display the differences between the workspace and the index?",
            answers: ['git diff', 'diff']
        },
        {
            type: 'free',
            text: "How to display the differences between the workspace and the repo?",
            answers: ['git diff HEAD', 'diff HEAD']
        },
        {
            type: 'free',
            text: "How to remove a file?",
            answers: ['git rm', 'rm']
        },
        {
            type: 'free',
            text: "How to move a file?",
            answers: ['git mv', 'mv']
        },
        {
            type: 'free',
            text: "How to display the project history?",
            answers: ['git log', 'log']
        },
        {
            type: 'free',
            text: "How to display the commits on the `maintenance` branch, but missing from `master`?",
            answers: ['git log master..maintenance', 'log master..maintenance']
        },
        {
            type: 'free',
            text: "How to remove a changed file from the index?",
            answers: ['git reset', 'reset']
        },
        {
            type: 'free',
            text: "How to rollback local changes?",
            answers: ['git checkout', 'checkout']
        }
    ]
};
angular.module("basics-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("basics-quizz").constant('quizz', quizz);
