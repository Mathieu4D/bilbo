var quizz = {
    title: 'Git - Advanced commands',
    description: 'The goal of this quizz is to assess your knowledge of Git advanced commands',
    questions: [
        {
            type: 'free',
            text: 'How to retrieve a single commit from another branch?',
            answers: ['git cherry-pick', 'cherry-pick']
        },
        {
            type: 'free',
            text: 'How to temporarily put local changes aside?',
            answers: ['git stash', 'stash']
        },
        {
            type: 'free',
            text: 'How to tag a version?',
            answers: ['git tag', 'tag']
        },
        {
            type: 'free',
            text: 'How to add a remote?',
            answers: ['git remote add', 'remote add']
        },
        {
            type: 'free',
            text: 'How to retrieve the changes from a remote named `upstream`?',
            answers: ['git fetch upstream', 'fetch upstream']
        },
        {
            type: 'free',
            text: 'How to retrieve the changes from a remote named `upstream` and merge them at once?',
            answers: ['git pull upstream', 'pull upstream']
        },
        {
            type: 'free',
            text: 'How to push a branch named `task1` to a remote named `upstream` under the name `task/1`?',
            answers: ['git push upstream task1:task/1', 'push upstream task1:task/1']
        },
        {
            type: 'free',
            text: 'How to delete a branch named `task/1` on the remote `upstream`?',
            answers: ['git push upstream :task/1', 'push upstream :task/1']
        },
        {
            type: 'free',
            text: 'How to locate a bug with Git?',
            answers: ['git bisect', 'bisect']
        },
        {
            type: 'free',
            text: 'Which option enables automatic conflict recording and subsequent resolution?',
            answers: ['git rerere', 'rerere']
        },
        {
            type: 'free',
            text: 'Which command displays a line author?',
            answers: ['git blame', 'blame']
        }
    ]
};
angular.module("advanced-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("advanced-quizz").constant('quizz', quizz);
