var quizz = {
    title: 'Git - Commandes avancées',
    description: 'Ce quizz a pour but de tester vos connaissances sur les commandes Git avancées',
    questions: [
        {
            type: 'free',
            text: 'Comment récupérer un seul commit d\'une autre branche ?',
            answers: ['git cherry-pick', 'cherry-pick']
        },
        {
            type: 'free',
            text: 'Comment mettre de côté temporairement des modifications ?',
            answers: ['git stash', 'stash']
        },
        {
            type: 'free',
            text: 'Comment tagger une version ?',
            answers: ['git tag', 'tag']
        },
        {
            type: 'free',
            text: 'Comment ajouter un remote ?',
            answers: ['git remote add', 'remote add']
        },
        {
            type: 'free',
            text: 'Comment récupérer les modifications depuis un remote nommé `upstream` ?',
            answers: ['git fetch upstream', 'fetch upstream']
        },
        {
            type: 'free',
            text: 'Comment récupérer les modifications depuis un remote nommé `upstream` et les merger en même temps ?',
            answers: ['git pull upstream', 'pull upstream']
        },
        {
            type: 'free',
            text: 'Comment pousser une branche `task1` vers le remote `upstream` avec le nom `task/1` ?',
            answers: ['git push upstream task1:task/1', 'push upstream task1:task/1']
        },
        {
            type: 'free',
            text: 'Comment supprimer une branche `task/1` sur le remote `upstream` ?',
            answers: ['git push upstream :task/1', 'push upstream :task/1']
        },
        {
            type: 'free',
            text: 'Comment rechercher un bug avec git ?',
            answers: ['git bisect', 'bisect']
        },
        {
            type: 'free',
            text: 'Quelle option permet de rappeler vos résolutions de conflits ?',
            answers: ['git rerere', 'rerere']
        },
        {
            type: 'free',
            text: 'Quelle commande permet de connaître l\'auteur d\'une ligne',
            answers: ['git blame', 'blame']
        }
    ]
};
angular.module("advanced-quizz", ['quizz', 'btford.markdown', 'ngAnimate']);
angular.module("advanced-quizz").constant('quizz', quizz);
